# Projeto-de-L-gica
Projeto de Lógica Computacional, com os alunos: Nívea Suzana, Julia Vieira, Luan Felipe, Davi Souza


